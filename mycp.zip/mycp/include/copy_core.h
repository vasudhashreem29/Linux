/* copy_core.h - the heart of mycp: Levels 1, 2 and 5 plus resume support. */
#ifndef MYCP_COPY_CORE_H
#define MYCP_COPY_CORE_H

#include "common.h"
#include "progress.h"

/* Copy one regular file. Returns a mycp_status_t. prog may be NULL. */
int  copy_file(const char *src, const char *dst, const mycp_options_t *opt,
               progress_t *prog, copy_stats_t *stats);
void stats_merge(copy_stats_t *into, const copy_stats_t *from);

#endif
