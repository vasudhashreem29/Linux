/* pool.h - worker thread pool that copies a plan in parallel (pthreads). */
#ifndef MYCP_POOL_H
#define MYCP_POOL_H

#include "dirwalk.h"
#include "progress.h"

int pool_run(const copy_plan_t *plan, const mycp_options_t *opt,
             progress_t *prog, copy_stats_t *total);

#endif
