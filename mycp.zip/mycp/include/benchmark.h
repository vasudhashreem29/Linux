/* benchmark.h - copy performance benchmark across buffer sizes. */
#ifndef MYCP_BENCHMARK_H
#define MYCP_BENCHMARK_H

#include "common.h"

/* Times copies of src with several buffer sizes (writes a temp file next to
 * dst_path and removes it). Returns 0 and the fastest size in *best_out. */
int benchmark_run(const char *src, const char *dst_path,
                  const mycp_options_t *opt, size_t *best_out);

#endif
