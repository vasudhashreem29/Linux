/*
 * platform.h - Linux/POSIX system headers and short aliases.
 * The aliases keep the rest of the code short and give one place to change
 * system-call details. This header must be the FIRST include of every .c file.
 */
#ifndef MYCP_PLATFORM_H
#define MYCP_PLATFORM_H

#ifndef _POSIX_C_SOURCE
#  define _POSIX_C_SOURCE 200809L
#endif

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <utime.h>

typedef struct stat    mycp_stat_t;
typedef struct utimbuf mycp_utimbuf_t;

#define mycp_stat(p, s)      stat((p), (s))
#define mycp_lstat(p, s)     lstat((p), (s))
#define mycp_fstat(fd, s)    fstat((fd), (s))
#define mycp_lseek(fd, o, w) lseek((fd), (off_t)(o), (w))
#define mycp_open            open
#define mycp_close           close
#define mycp_read            read
#define mycp_write           write
#define mycp_mkdir(p, m)     mkdir((p), (m))
#define mycp_chmod           chmod
#define mycp_utime           utime
#define mycp_isatty(fd)      isatty(fd)
#define mycp_fileno(f)       fileno(f)

#define MYCP_O_RDONLY        O_RDONLY
#define MYCP_O_WRONLY        O_WRONLY
#define MYCP_O_CREAT         O_CREAT
#define MYCP_O_TRUNC         O_TRUNC
#define MYCP_O_APPEND        O_APPEND
#define MYCP_O_BINARY        0

#define MYCP_ISREG(m)        S_ISREG(m)
#define MYCP_ISDIR(m)        S_ISDIR(m)
#define MYCP_ISLNK(m)        S_ISLNK(m)
#define mycp_same_file(a, b) ((a)->st_dev == (b)->st_dev && (a)->st_ino == (b)->st_ino)
#define MYCP_PATH_SEP        '/'

#endif /* MYCP_PLATFORM_H */
