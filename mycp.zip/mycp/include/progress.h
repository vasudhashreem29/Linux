/* progress.h - thread-safe progress bar (Level 4). */
#ifndef MYCP_PROGRESS_H
#define MYCP_PROGRESS_H

#include <pthread.h>

typedef struct {
    pthread_mutex_t    lock;
    unsigned long long total;
    unsigned long long done;
    double             start;
    double             last_draw;
    int                enabled;
    int                tty;
} progress_t;

void progress_init(progress_t *p, unsigned long long total, int enabled);
void progress_add(progress_t *p, unsigned long long n);   /* p may be NULL */
void progress_finish(progress_t *p);
void progress_destroy(progress_t *p);
void progress_clear_active(void);                         /* used by logger hook */

#endif
