/* fileinfo.h - file information display (Level 3, uses stat()). */
#ifndef MYCP_FILEINFO_H
#define MYCP_FILEINFO_H
#include <stdio.h>

int fileinfo_print(const char *path, const char *label, FILE *out);

#endif
