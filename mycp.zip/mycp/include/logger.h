/* logger.h - thread-safe logger (file via low-level write + console). */
#ifndef MYCP_LOGGER_H
#define MYCP_LOGGER_H

typedef enum { LOGLVL_DEBUG = 0, LOGLVL_INFO, LOGLVL_WARN, LOGLVL_ERROR } log_level_t;

int  logger_init(const char *path, int verbose, int quiet);
void logger_close(void);
void logger_set_console_hook(void (*hook)(void)); /* called before console output */
void logger_log(log_level_t lvl, const char *fmt, ...)
#if defined(__GNUC__)
    __attribute__((format(printf, 2, 3)))
#endif
    ;

#define LOG_DEBUG(...) logger_log(LOGLVL_DEBUG, __VA_ARGS__)
#define LOG_INFO(...)  logger_log(LOGLVL_INFO,  __VA_ARGS__)
#define LOG_WARN(...)  logger_log(LOGLVL_WARN,  __VA_ARGS__)
#define LOG_ERROR(...) logger_log(LOGLVL_ERROR, __VA_ARGS__)

#endif
