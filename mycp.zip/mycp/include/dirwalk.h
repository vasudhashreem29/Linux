/* dirwalk.h - recursive directory traversal (opendir/readdir) -> copy plan. */
#ifndef MYCP_DIRWALK_H
#define MYCP_DIRWALK_H

#include "common.h"

/* Linked list of files to copy. */
typedef struct file_node {
    char              *src;
    char              *dst;
    unsigned long long size;
    struct file_node  *next;
} file_node_t;

/* Linked list of directories whose permissions/times are applied last. */
typedef struct dir_node {
    char            *path;
    unsigned int     mode;
    uid_t            uid;
    gid_t            gid;
    time_t           atime;
    time_t           mtime;
    struct dir_node *next;
} dir_node_t;

typedef struct {
    file_node_t       *head;
    file_node_t       *tail;
    unsigned long      file_count;
    unsigned long long total_bytes;
    dir_node_t        *dirs;
    unsigned long      dir_count;
    unsigned long      symlink_count;
    unsigned long      skipped_special;
    unsigned long      errors;
} copy_plan_t;

void plan_init(copy_plan_t *plan);
int  plan_build(copy_plan_t *plan, const char *src_root, const char *dst_root,
                const mycp_options_t *opt);
void plan_apply_dir_attrs(const copy_plan_t *plan, const mycp_options_t *opt);
void plan_free(copy_plan_t *plan);

#endif
