/* jobqueue.h - blocking FIFO queue (singly linked list) for the thread pool. */
#ifndef MYCP_JOBQUEUE_H
#define MYCP_JOBQUEUE_H

#include <pthread.h>
#include <stddef.h>

typedef struct jq_node {
    void           *data;
    struct jq_node *next;
} jq_node_t;

typedef struct {
    jq_node_t      *head;
    jq_node_t      *tail;
    size_t          size;
    int             closed;
    pthread_mutex_t lock;
    pthread_cond_t  not_empty;
} job_queue_t;

int   jq_init(job_queue_t *q);
int   jq_push(job_queue_t *q, void *data);   /* 0 ok, -1 out of memory */
void *jq_pop(job_queue_t *q);                /* blocks; NULL when closed+empty */
void  jq_close(job_queue_t *q);
void  jq_destroy(job_queue_t *q);

#endif
