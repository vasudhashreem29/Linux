/* resume.h - find where an interrupted copy can safely continue. */
#ifndef MYCP_RESUME_H
#define MYCP_RESUME_H
#include <stddef.h>

/* Returns the byte offset up to which dst is an exact prefix of the source
 * (0 = start over, src_size = already complete, -1 = error). */
long long resume_find_offset(int src_fd, const char *dst_path,
                             long long src_size, size_t bufsize);

#endif
