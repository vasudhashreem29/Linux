/* verify.h - copy verification (byte-by-byte compare + FNV-1a checksum). */
#ifndef MYCP_VERIFY_H
#define MYCP_VERIFY_H
#include <stddef.h>

/* 0 = identical, 1 = differ, -1 = I/O error. */
int verify_files(const char *src, const char *dst, size_t bufsize,
                 unsigned long long *hash_out, long long *diff_offset);

/* Same, but logs the outcome. Returns 0 on success, -1 on mismatch/error. */
int verify_copy(const char *src, const char *dst, size_t bufsize);

#endif
