/* util.h - small helpers: time, sizes, paths, errors and robust read/write. */
#ifndef MYCP_UTIL_H
#define MYCP_UTIL_H

#include "platform.h"
#include <stddef.h>
#include <time.h>

double      util_now(void);                                   /* monotonic seconds */
void        util_human_size(unsigned long long bytes, char *buf, size_t n);
int         util_parse_size(const char *s, size_t *out);      /* "64K", "1M" ...   */
int         util_path_join(char *out, size_t n, const char *a, const char *b);
int         util_basename(const char *path, char *out, size_t n);
char       *util_strdup(const char *s);
const char *util_errstr(int err, char *buf, size_t n);        /* thread-safe       */
void        util_format_time(time_t t, char *buf, size_t n);
void        util_mode_string(unsigned int mode, char out[11]);

/* Low-level I/O helpers built only on read()/write(). */
long long   util_read_full(int fd, char *buf, size_t n);      /* bytes, 0=EOF, -1=err */
int         util_write_all(int fd, const char *buf, size_t n, unsigned long long *calls);

#endif
