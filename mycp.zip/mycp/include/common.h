/* common.h - shared types, constants and options for the whole project. */
#ifndef MYCP_COMMON_H
#define MYCP_COMMON_H

#include "platform.h"
#include <signal.h>
#include <stddef.h>

#define MYCP_VERSION        "1.0.0"
#define MYCP_DEFAULT_BUFFER (64UL * 1024UL)
#define MYCP_MAX_BUFFER     (256UL * 1024UL * 1024UL)
#define MYCP_MAX_JOBS       64
#define MYCP_PATH_MAX       4096

/* Result of a single file copy. */
typedef enum {
    MYCP_OK          = 0,
    MYCP_ERROR       = -1,
    MYCP_SKIPPED     = 1,
    MYCP_INTERRUPTED = 2
} mycp_status_t;

/* All command-line settings (filled by cli.c, read-only everywhere else). */
typedef struct {
    size_t      buffer_size;   /* Level 2: -s            */
    int         buffer_set;    /* user gave -s explicitly */
    int         show_info;     /* Level 3: -i            */
    int         show_progress; /* Level 4: -p            */
    int         preserve;      /* Level 5: default on    */
    int         recursive;     /* Ext: -r                */
    int         benchmark;     /* Ext: -b                */
    int         verify;        /* Ext: -V                */
    int         resume;        /* Ext: -c                */
    int         no_clobber;    /* -n                     */
    int         jobs;          /* parallel copy: -j      */
    int         verbose;
    int         quiet;
    const char *log_path;      /* Ext: -l                */
} mycp_options_t;

/* Performance statistics (one per worker thread, merged at the end). */
typedef struct {
    unsigned long long bytes_copied;
    unsigned long long read_calls;
    unsigned long long write_calls;
    unsigned long      files_copied;
    unsigned long      files_skipped;
    unsigned long      files_failed;
    unsigned long      files_verified;
    unsigned long      verify_failed;
} copy_stats_t;

/* Set by SIGINT/SIGTERM handler; polled by the copy loops. */
extern volatile sig_atomic_t g_interrupted;

#endif /* MYCP_COMMON_H */
