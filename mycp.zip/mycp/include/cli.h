/* cli.h - command-line parsing (hand written: no getopt_long dependency). */
#ifndef MYCP_CLI_H
#define MYCP_CLI_H

#include "common.h"
#include <stdio.h>

typedef struct {
    mycp_options_t opt;
    const char    *src;
    const char    *dst;
} cli_args_t;

/* 0 = run, 1 = exit successfully (help/version shown), -1 = usage error. */
int  cli_parse(int argc, char **argv, cli_args_t *out);
void cli_usage(FILE *f);

#endif
