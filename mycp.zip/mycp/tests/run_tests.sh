#!/bin/sh
# Automated tests for mycp.   Usage: sh tests/run_tests.sh ./mycp
MYCP=${1:-./mycp}
case "$MYCP" in /*) ;; *) MYCP="$(pwd)/$MYCP" ;; esac
T=$(mktemp -d /tmp/mycp_test.XXXXXX) || exit 1
trap 'chmod -R u+rwx "$T" 2>/dev/null; rm -rf "$T"' EXIT
PASS=0; FAIL=0

ok()   { PASS=$((PASS+1)); printf '  [PASS] %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); printf '  [FAIL] %s\n' "$1"; }
check(){ # check "name" command...
    name=$1; shift
    if "$@" >/dev/null 2>&1; then ok "$name"; else bad "$name"; fi
}
fails(){ # fails "name" command...   (command must exit non-zero)
    name=$1; shift
    if "$@" >/dev/null 2>&1; then bad "$name"; else ok "$name"; fi
}
mode() { stat -c %a "$1"; }

cd "$T" || exit 1
head -c 3000000 /dev/urandom > big.bin
printf 'hello world\n' > small.txt
: > empty.txt

echo "== Level 1: basic copy =="
check "copy small file"            $MYCP small.txt out_small.txt
check "small file identical"       cmp small.txt out_small.txt
check "copy 3 MB file"             $MYCP big.bin out_big.bin
check "big file identical"         cmp big.bin out_big.bin
check "copy empty file"            $MYCP empty.txt out_empty.txt
check "empty file identical"       cmp empty.txt out_empty.txt
check "overwrite existing file"    $MYCP small.txt out_big.bin
check "overwritten content right"  cmp small.txt out_big.bin
mkdir dest_dir
check "copy into directory"        $MYCP small.txt dest_dir
check "file landed in directory"   cmp small.txt dest_dir/small.txt

echo "== Level 2: configurable buffer size =="
for b in 1 512 4096 64K 1M 4M; do
    check "buffer $b"              $MYCP -s $b big.bin buf_$b.bin
    check "buffer $b identical"    cmp big.bin buf_$b.bin
done
fails "reject buffer 0"            $MYCP -s 0 small.txt x.txt
fails "reject buffer 'abc'"        $MYCP -s abc small.txt x.txt
fails "reject buffer -5"           $MYCP -s -5 small.txt x.txt
fails "reject buffer > 256M"       $MYCP -s 1G small.txt x.txt
$MYCP -s 4096 -q big.bin cnt.bin >/dev/null; 
reads=$($MYCP -s 4096 big.bin cnt2.bin | sed -n 's/.*read() calls: \([0-9]*\).*/\1/p')
[ "$reads" -ge 700 ] && ok "4K buffer => many read() calls ($reads)" || bad "read call count ($reads)"
reads=$($MYCP -s 1M big.bin cnt3.bin | sed -n 's/.*read() calls: \([0-9]*\).*/\1/p')
[ "$reads" -le 5 ] && ok "1M buffer => few read() calls ($reads)" || bad "read call count ($reads)"

echo "== Level 3: file information =="
out=$($MYCP -i small.txt info_out.txt)
echo "$out" | grep -q "Permissions" && ok "info shows permissions"      || bad "info permissions"
echo "$out" | grep -q "Source"      && ok "info shows source section"   || bad "info source"
echo "$out" | grep -q "Destination" && ok "info shows destination"      || bad "info destination"
echo "$out" | grep -q "12 bytes"    && ok "info shows size in bytes"    || bad "info size"

echo "== Level 4: progress bar =="
check "progress runs"              $MYCP -p big.bin prog.bin
check "progress copy identical"    cmp big.bin prog.bin
check "progress on empty file"     $MYCP -p empty.txt prog_empty.txt
if command -v script >/dev/null 2>&1; then
    script -qec "$MYCP -p big.bin prog_tty.bin" /dev/null 2>&1 | grep -q '100%' \
        && ok "progress bar reaches 100% on a terminal" || bad "progress 100%"
fi

echo "== Level 5: preserve permissions =="
printf 'x' > perm640.txt; chmod 640 perm640.txt
printf '#!/bin/sh\n' > run755.sh; chmod 755 run755.sh
printf 'ro' > ro444.txt; chmod 444 ro444.txt
check "copy 640 file"              $MYCP perm640.txt p640.txt
[ "$(mode p640.txt)" = "640" ] && ok "mode 640 preserved" || bad "mode 640 preserved"
check "copy 755 file"              $MYCP run755.sh p755.sh
[ "$(mode p755.sh)" = "755" ] && ok "mode 755 preserved" || bad "mode 755 preserved"
check "copy read-only file"        $MYCP ro444.txt p444.txt
[ "$(mode p444.txt)" = "444" ] && ok "mode 444 preserved" || bad "mode 444 preserved"
check "re-copy over read-only dst" $MYCP small.txt p444.txt
[ "$(stat -c %Y small.txt)" = "$(stat -c %Y p640.txt)" ] || true
touch -d '2020-01-02 03:04:05' small.txt
$MYCP small.txt p_time.txt >/dev/null
[ "$(stat -c %Y small.txt)" = "$(stat -c %Y p_time.txt)" ] && ok "mtime preserved" || bad "mtime preserved"
$MYCP --no-preserve perm640.txt np.txt >/dev/null
[ "$(mode np.txt)" != "640" ] && ok "--no-preserve uses umask mode" || bad "--no-preserve"

echo "== Recursive directory copy =="
mkdir -p tree/a/b tree/empty_dir tree/ro_dir
echo one > tree/one.txt; echo two > tree/a/two.txt; echo three > tree/a/b/three.txt
head -c 500000 /dev/urandom > tree/a/b/blob.bin
echo secret > tree/ro_dir/s.txt
chmod 600 tree/a/two.txt; chmod 555 tree/ro_dir
ln -s one.txt tree/link_to_one
ln -s a/b tree/link_to_dir
check "recursive copy"             $MYCP -r tree tree_copy
check "tree identical (diff -r)"   diff -r tree tree_copy
[ -d tree_copy/empty_dir ] && ok "empty directory copied" || bad "empty directory copied"
[ "$(readlink tree_copy/link_to_one)" = "one.txt" ] && ok "symlink recreated" || bad "symlink recreated"
[ "$(mode tree_copy/a/two.txt)" = "600" ] && ok "file perms preserved in tree" || bad "file perms in tree"
[ "$(mode tree_copy/ro_dir)" = "555" ] && ok "read-only dir perms preserved" || bad "dir perms in tree"
fails "dir without -r is refused"  $MYCP tree tree_norec
mkdir existing_dst
check "recursive into existing dir" $MYCP -r tree existing_dst
check "copied under dst/basename"  diff -r tree existing_dst/tree
check "dir into itself terminates" timeout 20 $MYCP -r tree tree/inner_copy
[ ! -e tree/inner_copy/inner_copy ] && ok "no infinite recursion" || bad "no infinite recursion"
rm -rf tree/inner_copy
(cd tree && fails "same directory (. onto .) refused" $MYCP -r . .)

echo "== Parallel copy (pthreads) =="
mkdir -p par
i=0; while [ $i -lt 60 ]; do head -c $((i*7000+1)) /dev/urandom > par/f$i.bin; i=$((i+1)); done
for j in 1 2 4 8 16; do
    rm -rf par_out
    check "-j $j copy"             $MYCP -r -j $j par par_out
    check "-j $j identical"        diff -r par par_out
done
fails "reject -j 0"                $MYCP -r -j 0 par x
fails "reject -j 999"              $MYCP -r -j 999 par x

echo "== Verification =="
out=$($MYCP -V big.bin ver.bin)
echo "$out" | grep -q "1 OK, 0 FAILED" && ok "verify reports OK" || bad "verify reports OK"
check "verify in recursive mode"   $MYCP -r -V -j 4 tree tree_ver
$MYCP -V -l ver.log big.bin ver2.bin >/dev/null
grep -q "FNV-1a64" ver.log && ok "checksum logged" || bad "checksum logged"

echo "== Resume interrupted copy =="
head -c 1000000 big.bin > partial.bin
check "resume from clean prefix"   $MYCP -c big.bin partial.bin
check "resumed file identical"     cmp big.bin partial.bin
head -c 1000000 big.bin > torn.bin; head -c 50000 /dev/zero >> torn.bin
check "resume repairs garbage tail" $MYCP -c big.bin torn.bin
check "repaired file identical"    cmp big.bin torn.bin
head -c 100000 /dev/urandom > wrong.bin
check "resume with unrelated dst"  $MYCP -c big.bin wrong.bin
check "unrelated dst fixed"        cmp big.bin wrong.bin
cp big.bin longer.bin; head -c 1000 /dev/urandom >> longer.bin
check "resume with oversized dst"  $MYCP -c big.bin longer.bin
check "oversized dst truncated"    cmp big.bin longer.bin
out=$($MYCP -c big.bin longer.bin)
echo "$out" | grep -q "skipped 1" && ok "complete file is skipped on resume" || bad "complete file skipped"
check "resume with missing dst"    $MYCP -c big.bin fresh_resume.bin
check "fresh resume identical"     cmp big.bin fresh_resume.bin
# real interruption: kill a running copy, then resume
head -c 60000000 /dev/urandom > huge.bin
$MYCP -s 4096 huge.bin huge_out.bin >/dev/null 2>&1 &
pid=$!; sleep 0.05; kill -INT $pid 2>/dev/null; wait $pid 2>/dev/null; code=$?
if [ "$code" = "130" ]; then ok "SIGINT => exit 130"; else ok "copy finished before SIGINT (exit $code)"; fi
check "resume after SIGINT"        $MYCP -c huge.bin huge_out.bin
check "result identical after SIGINT" cmp huge.bin huge_out.bin

echo "== Logging =="
check "log file written"           $MYCP -l my.log small.txt log_out.txt
grep -q "copied" my.log && ok "log has a 'copied' entry" || bad "log entry"
grep -Eq '^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9:]{8} \[INFO ' my.log && ok "log has timestamp + level" || bad "log format"
$MYCP -l my.log nonexistent.txt x.txt >/dev/null 2>&1
grep -q "ERROR" my.log && ok "errors are logged" || bad "errors logged"
$MYCP -r -j 4 -l tree.log tree tree_logged >/dev/null 2>&1
lines=$(grep -c "copied" tree.log)
[ "$lines" -ge 5 ] && ok "parallel log entries intact ($lines)" || bad "parallel log ($lines)"
fails "unwritable log path"        $MYCP -l /nonexistent_dir/x.log small.txt y.txt

echo "== Benchmark =="
out=$($MYCP -b big.bin bench_out.bin)
echo "$out" | grep -q "fastest" && ok "benchmark prints a winner" || bad "benchmark winner"
echo "$out" | grep -q "MB/s" && ok "benchmark prints throughput" || bad "benchmark throughput"
check "benchmark also copied file" cmp big.bin bench_out.bin
[ ! -e bench_out.bin.mycp_bench.tmp ] && ok "benchmark temp file removed" || bad "benchmark temp removed"
fails "benchmark rejects directory" $MYCP -b tree xx

echo "== No-clobber =="
echo AAA > nc_src.txt; echo BBB > nc_dst.txt
check "no-clobber run"             $MYCP -n nc_src.txt nc_dst.txt
[ "$(cat nc_dst.txt)" = "BBB" ] && ok "existing file not overwritten" || bad "no-clobber"

echo "== Error handling =="
fails "missing source"             $MYCP no_such_file.txt x.txt
fails "same file"                  $MYCP small.txt small.txt
ln small.txt hard.txt
fails "hard link = same file"      $MYCP small.txt hard.txt
fails "dst in missing directory"   $MYCP small.txt no_dir/x.txt
fails "no arguments"               $MYCP
fails "one argument"               $MYCP small.txt
fails "three arguments"            $MYCP a b c
fails "unknown option"             $MYCP --bogus a b
fails "missing option value"       $MYCP small.txt x.txt -s
$MYCP no_such.txt x.txt >/dev/null 2>&1; [ $? -eq 1 ] && ok "copy failure => exit 1" || bad "exit 1"
$MYCP >/dev/null 2>&1; [ $? -eq 2 ] && ok "usage error => exit 2" || bad "exit 2"
mkfifo fifo 2>/dev/null && { fails "FIFO source refused" timeout 5 $MYCP fifo y.txt; }
chmod 000 unreadable.txt 2>/dev/null; echo data > unreadable.txt; chmod 000 unreadable.txt
if [ "$(id -u)" != "0" ]; then fails "unreadable source" $MYCP unreadable.txt y.txt; fi
check "--help"                     $MYCP --help
check "--version"                  $MYCP --version
check "combined short flags"       $MYCP -pi -s64K small.txt combo.txt
check "options after files"        $MYCP small.txt after.txt -p
check "-- ends options"            $MYCP -- small.txt dd.txt
check "long opt with ="            $MYCP --buffer-size=8K small.txt eq.txt


echo "== Ownership (needs root) =="
if [ "$(id -u)" = "0" ]; then
    echo own > own.txt; chown 1234:4321 own.txt
    $MYCP own.txt own_copy.txt >/dev/null
    [ "$(stat -c %u:%g own_copy.txt)" = "1234:4321" ] && ok "file owner/group preserved" || bad "file owner preserved"
    mkdir own_dir; chown 1234:4321 own_dir; echo x > own_dir/f
    $MYCP -r own_dir own_dir_copy >/dev/null
    [ "$(stat -c %u:%g own_dir_copy)" = "1234:4321" ] && ok "directory owner preserved" || bad "dir owner preserved"
else
    echo "  (skipped: not root)"
fi

echo "== Awkward names and many files =="
mkdir -p odd
echo a > "odd/with space.txt"; echo b > "odd/-dash.txt"; echo c > "odd/unic\303\266de.txt"; echo d > "odd/.hidden"
mkdir -p "odd/dir with space"; echo e > "odd/dir with space/x y.txt"
check "odd file names"             $MYCP -r odd odd_copy
check "odd names identical"        diff -r odd odd_copy
mkdir -p many
i=0; while [ $i -lt 1500 ]; do echo "file $i" > many/f$i.txt; i=$((i+1)); done
check "1500 small files -j 8"      $MYCP -r -j 8 -V many many_copy
check "1500 files identical"       diff -r many many_copy
deep=deep; i=0; while [ $i -lt 60 ]; do deep="$deep/d$i"; i=$((i+1)); done
mkdir -p "$deep"; echo bottom > "$deep/f.txt"
check "60-level deep tree"         $MYCP -r deep deep_copy
check "deep tree identical"        diff -r deep deep_copy

echo "== Large file (> 2 GiB, 64-bit offsets) =="
avail=$(df -k . | awk 'NR==2{print $4}')
if [ "$avail" -gt 5000000 ]; then
    head -c 1000 /dev/urandom > head.part
    truncate -s 2300M large.bin
    dd if=head.part of=large.bin conv=notrunc 2>/dev/null
    printf 'END-MARKER' | dd of=large.bin bs=1 seek=$((2300*1024*1024-10)) conv=notrunc 2>/dev/null
    check "copy 2.3 GiB file"      $MYCP -s 1M large.bin large_out.bin
    check "2.3 GiB identical"      cmp large.bin large_out.bin
    check "resume 2.3 GiB file"    $MYCP -c -V large.bin large_out.bin
    rm -f large.bin large_out.bin
else
    echo "  (skipped: not enough disk space)"
fi

echo
echo "Result: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
