/* copy_core.c - Levels 1, 2, 5 (+ resume): low-level file copy using only
 * open(), read(), write(), lseek(), fstat(), chmod(), close(). */
#include "platform.h"
#include "copy_core.h"
#include "logger.h"
#include "resume.h"
#include "util.h"

#include <stdlib.h>
#include <string.h>

void stats_merge(copy_stats_t *into, const copy_stats_t *from)
{
    into->bytes_copied   += from->bytes_copied;
    into->read_calls     += from->read_calls;
    into->write_calls    += from->write_calls;
    into->files_copied   += from->files_copied;
    into->files_skipped  += from->files_skipped;
    into->files_failed   += from->files_failed;
    into->files_verified += from->files_verified;
    into->verify_failed  += from->verify_failed;
}

int copy_file(const char *src, const char *dst, const mycp_options_t *opt,
              progress_t *prog, copy_stats_t *stats)
{
    mycp_stat_t sst, dstat;
    int sfd = -1, dfd = -1, rc = MYCP_ERROR, dst_exists, flags;
    char *buf = NULL, err[128];
    size_t bufsize;
    long long offset = 0, expected;
    unsigned long long copied = 0;
    int probed = 0;                     /* resume_find_offset() moved the source position */

    if (g_interrupted)
        return MYCP_INTERRUPTED;

    /* ---- inspect source (stat first so we never block opening a FIFO) ---- */
    if (mycp_stat(src, &sst) != 0) {
        LOG_ERROR("cannot stat '%s': %s", src, util_errstr(errno, err, sizeof err));
        goto done;
    }
    if (!MYCP_ISREG(sst.st_mode)) {
        LOG_ERROR("'%s' is not a regular file", src);
        goto done;
    }

    /* ---- inspect destination ---- */
    dst_exists = (mycp_stat(dst, &dstat) == 0);
    if (dst_exists) {
        if (MYCP_ISDIR(dstat.st_mode)) {
            LOG_ERROR("destination '%s' is a directory", dst);
            goto done;
        }
        if (mycp_same_file(&sst, &dstat)) {
            LOG_ERROR("'%s' and '%s' are the same file", src, dst);
            goto done;
        }
        if (opt->no_clobber) {
            LOG_INFO("skipping '%s': destination exists (--no-clobber)", dst);
            progress_add(prog, (unsigned long long)sst.st_size);
            rc = MYCP_SKIPPED;
            goto done;
        }
    }

    /* ---- open source ---- */
    sfd = mycp_open(src, MYCP_O_RDONLY | MYCP_O_BINARY);
    if (sfd < 0) {
        LOG_ERROR("cannot open '%s' for reading: %s", src, util_errstr(errno, err, sizeof err));
        goto done;
    }
    if (mycp_fstat(sfd, &sst) != 0) {
        LOG_ERROR("fstat failed on '%s': %s", src, util_errstr(errno, err, sizeof err));
        goto done;
    }
    expected = (long long)sst.st_size;

    /* Level 2: configurable buffer (never bigger than the file itself). */
    bufsize = opt->buffer_size;
    if ((unsigned long long)expected < bufsize)
        bufsize = expected > 0 ? (size_t)expected : 1;
    buf = (char *)malloc(bufsize);
    if (buf == NULL) {
        LOG_ERROR("out of memory allocating %lu-byte buffer", (unsigned long)bufsize);
        goto done;
    }

    /* ---- resume support ---- */
    if (opt->resume && dst_exists) {
        offset = resume_find_offset(sfd, dst, expected, bufsize);
        probed = 1;
        if (offset < 0) {
            LOG_ERROR("cannot examine existing '%s' for resume", dst);
            goto done;
        }
        if (offset == expected) {
            LOG_INFO("skipping '%s': already complete", dst);
            progress_add(prog, (unsigned long long)expected);
            rc = MYCP_SKIPPED;
            goto done;
        }
        if (offset > 0)
            LOG_INFO("resuming '%s' at byte %lld of %lld", dst, offset, expected);
    }

    /* ---- open destination.
     * With --preserve we create 0600 and apply the real mode at the end, so a
     * restrictive source mode is never exposed. Without it we use 0666 and let
     * the umask decide (like cp). ---- */
    flags = MYCP_O_WRONLY | MYCP_O_CREAT | MYCP_O_BINARY | (offset == 0 ? MYCP_O_TRUNC : 0);
    dfd = mycp_open(dst, flags, opt->preserve ? 0600 : 0666);
    if (dfd < 0 && errno == EACCES && dst_exists) {
        /* A previous backup may have preserved a read-only mode. */
        mycp_chmod(dst, 0600);
        dfd = mycp_open(dst, flags, opt->preserve ? 0600 : 0666);
    }
    if (dfd < 0) {
        LOG_ERROR("cannot open '%s' for writing: %s", dst, util_errstr(errno, err, sizeof err));
        goto done;
    }

    /* Reposition: the resume probe read from the start of the source, so the
     * source must ALWAYS be seeked back (even to 0); dst only when resuming. */
    if (probed || offset > 0) {
        if (mycp_lseek(sfd, offset, SEEK_SET) < 0 ||
            (offset > 0 && mycp_lseek(dfd, offset, SEEK_SET) < 0)) {
            LOG_ERROR("lseek failed while resuming '%s': %s", dst, util_errstr(errno, err, sizeof err));
            goto done;
        }
        if (offset > 0)
            progress_add(prog, (unsigned long long)offset);
    }

    /* ---- Level 1: the copy loop ---- */
    for (;;) {
        long long n;

        if (g_interrupted) {
            LOG_WARN("interrupted while copying '%s' (partial file kept, use --resume)", dst);
            rc = MYCP_INTERRUPTED;
            goto done;
        }
        n = (long long)mycp_read(sfd, buf, bufsize);
        stats->read_calls++;
        if (n < 0) {
            if (errno == EINTR)
                continue;
            LOG_ERROR("read error on '%s': %s", src, util_errstr(errno, err, sizeof err));
            goto done;
        }
        if (n == 0)
            break;                                  /* EOF */
        if (util_write_all(dfd, buf, (size_t)n, &stats->write_calls) != 0) {
            LOG_ERROR("write error on '%s': %s", dst, util_errstr(errno, err, sizeof err));
            goto done;
        }
        copied += (unsigned long long)n;
        stats->bytes_copied += (unsigned long long)n;
        progress_add(prog, (unsigned long long)n);
    }

    if ((long long)copied + offset != expected)
        LOG_WARN("'%s' changed size during the copy (expected %lld bytes, copied %lld)",
                 src, expected, (long long)copied + offset);

    /* close() can report delayed write errors (e.g. on NFS) - check it. */
    if (mycp_close(dfd) != 0) {
        dfd = -1;
        LOG_ERROR("close failed on '%s': %s", dst, util_errstr(errno, err, sizeof err));
        goto done;
    }
    dfd = -1;

    /* ---- Level 5: preserve permissions (and timestamps) ---- */
    if (opt->preserve) {
        mycp_utimbuf_t ub;

        /* Ownership first (chown clears setuid bits); only root can usually do it. */
        if (chown(dst, sst.st_uid, sst.st_gid) != 0 && errno != EPERM)
            LOG_WARN("cannot preserve owner of '%s': %s", dst, util_errstr(errno, err, sizeof err));
        if (mycp_chmod(dst, (unsigned int)(sst.st_mode & 0777)) != 0) {
            LOG_ERROR("cannot set permissions on '%s': %s", dst, util_errstr(errno, err, sizeof err));
            goto done;
        }
        ub.actime  = sst.st_atime;
        ub.modtime = sst.st_mtime;
        if (mycp_utime(dst, &ub) != 0)
            LOG_WARN("cannot preserve timestamps of '%s': %s", dst, util_errstr(errno, err, sizeof err));
    }

    LOG_INFO("copied '%s' -> '%s' (%lld bytes)", src, dst, expected);
    rc = MYCP_OK;

done:
    if (sfd >= 0)
        mycp_close(sfd);
    if (dfd >= 0)
        mycp_close(dfd);
    free(buf);
    if (rc == MYCP_OK)
        stats->files_copied++;
    else if (rc == MYCP_SKIPPED)
        stats->files_skipped++;
    else if (rc == MYCP_ERROR)
        stats->files_failed++;
    return rc;
}
