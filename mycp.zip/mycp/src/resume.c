/* resume.c - Extension: resume an interrupted copy.
 *
 * Instead of trusting the destination size blindly, we compare the existing
 * destination bytes with the source and continue from the FIRST DIFFERENCE.
 * This also repairs a torn/garbage tail left by a crash. */
#include "platform.h"
#include "resume.h"
#include "util.h"

#include <stdlib.h>
#include <string.h>

long long resume_find_offset(int src_fd, const char *dst_path,
                             long long src_size, size_t bufsize)
{
    mycp_stat_t dst;
    int dfd;
    char *a, *b;
    long long pos = 0, dsize;

    dfd = mycp_open(dst_path, MYCP_O_RDONLY | MYCP_O_BINARY);
    if (dfd < 0)
        return 0;                       /* cannot read it: start over      */
    if (mycp_fstat(dfd, &dst) != 0) {
        mycp_close(dfd);
        return 0;
    }
    dsize = (long long)dst.st_size;
    if (dsize == 0 || dsize > src_size) {
        mycp_close(dfd);
        return 0;                       /* nothing usable / dst too long   */
    }

    a = (char *)malloc(bufsize * 2);
    if (a == NULL) {
        mycp_close(dfd);
        return -1;
    }
    b = a + bufsize;

    if (mycp_lseek(src_fd, 0, SEEK_SET) < 0) {
        free(a);
        mycp_close(dfd);
        return -1;
    }

    while (pos < dsize) {
        size_t want = (size_t)((dsize - pos) < (long long)bufsize ? (dsize - pos) : (long long)bufsize);
        long long ra = util_read_full(src_fd, a, want);
        long long rb = util_read_full(dfd, b, want);
        size_t common, i;

        if (ra < 0 || rb < 0) {
            free(a);
            mycp_close(dfd);
            return -1;
        }
        common = (size_t)(ra < rb ? ra : rb);
        if (memcmp(a, b, common) == 0) {
            pos += (long long)common;
            if (common < want)
                break;                  /* short read: stop here           */
            continue;
        }
        for (i = 0; i < common && a[i] == b[i]; i++)
            ;
        pos += (long long)i;            /* first differing byte            */
        break;
    }

    free(a);
    mycp_close(dfd);
    return pos;
}
