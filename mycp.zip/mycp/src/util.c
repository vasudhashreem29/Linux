/* util.c - helpers: time, sizes, paths, errors and robust read/write loops. */
#include "platform.h"
#include "util.h"
#include "common.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

double util_now(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

void util_human_size(unsigned long long bytes, char *buf, size_t n)
{
    static const char *units[] = { "B", "KB", "MB", "GB", "TB" };
    double v = (double)bytes;
    int u = 0;

    if (bytes < 1024ULL) {
        snprintf(buf, n, "%llu B", bytes);
        return;
    }
    while (v >= 1024.0 && u < 4) {
        v /= 1024.0;
        u++;
    }
    snprintf(buf, n, "%.2f %s", v, units[u]);
}

/* Accepts "4096", "64K", "64KB", "1M", "2G" (powers of 1024). */
int util_parse_size(const char *s, size_t *out)
{
    char *end;
    unsigned long long v, mult = 1;

    if (s == NULL || !isdigit((unsigned char)s[0]))
        return -1;
    errno = 0;
    v = strtoull(s, &end, 10);
    if (errno != 0 || end == s)
        return -1;
    if (*end != '\0') {
        switch (toupper((unsigned char)*end)) {
        case 'K': mult = 1024ULL; break;
        case 'M': mult = 1024ULL * 1024ULL; break;
        case 'G': mult = 1024ULL * 1024ULL * 1024ULL; break;
        case 'B': mult = 1; break;
        default:  return -1;
        }
        end++;
        if (mult != 1 && toupper((unsigned char)*end) == 'B')
            end++;
        if (*end != '\0')
            return -1;
    }
    if (v > MYCP_MAX_BUFFER / mult)
        return -1;
    v *= mult;
    if (v == 0 || v > MYCP_MAX_BUFFER)
        return -1;
    *out = (size_t)v;
    return 0;
}

static int is_sep(char c)
{
    return c == '/';
}

int util_path_join(char *out, size_t n, const char *a, const char *b)
{
    size_t la = strlen(a);
    int w;

    if (la > 0 && is_sep(a[la - 1]))
        w = snprintf(out, n, "%s%s", a, b);
    else
        w = snprintf(out, n, "%s%c%s", a, MYCP_PATH_SEP, b);
    return (w < 0 || (size_t)w >= n) ? -1 : 0;
}

int util_basename(const char *path, char *out, size_t n)
{
    size_t len = strlen(path), end, start;

    if (len == 0)
        return -1;
    end = len;
    while (end > 1 && is_sep(path[end - 1]))   /* strip trailing separators */
        end--;
    start = end;
    while (start > 0 && !is_sep(path[start - 1]))
        start--;
    if (end - start + 1 > n)
        return -1;
    memcpy(out, path + start, end - start);
    out[end - start] = '\0';
    return 0;
}

char *util_strdup(const char *s)
{
    size_t n = strlen(s) + 1;
    char *p = (char *)malloc(n);

    if (p != NULL)
        memcpy(p, s, n);
    return p;
}

const char *util_errstr(int err, char *buf, size_t n)
{
    if (strerror_r(err, buf, n) != 0)
        snprintf(buf, n, "error %d", err);
    return buf;
}

void util_format_time(time_t t, char *buf, size_t n)
{
    struct tm tmv;
    if (localtime_r(&t, &tmv) == NULL) { snprintf(buf, n, "?"); return; }
    if (strftime(buf, n, "%Y-%m-%d %H:%M:%S", &tmv) == 0)
        snprintf(buf, n, "?");
}

void util_mode_string(unsigned int mode, char out[11])
{
    static const char rwx[] = "rwxrwxrwx";
    int i;

    out[0] = MYCP_ISDIR(mode) ? 'd' : MYCP_ISLNK(mode) ? 'l' : '-';
    for (i = 0; i < 9; i++)
        out[i + 1] = (mode & (1u << (8 - i))) ? rwx[i] : '-';
    out[10] = '\0';
}

/* Read until n bytes, EOF or error (read() may legally return less). */
long long util_read_full(int fd, char *buf, size_t n)
{
    size_t got = 0;

    while (got < n) {
        long long r = (long long)mycp_read(fd, buf + got, n - got);
        if (r < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        if (r == 0)
            break;
        got += (size_t)r;
    }
    return (long long)got;
}

/* write() may write less than requested: loop until everything is out. */
int util_write_all(int fd, const char *buf, size_t n, unsigned long long *calls)
{
    size_t off = 0;

    while (off < n) {
        long long w = (long long)mycp_write(fd, buf + off, n - off);
        if (calls != NULL)
            (*calls)++;
        if (w < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        off += (size_t)w;
    }
    return 0;
}
