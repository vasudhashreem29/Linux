/* pool.c - Extension: parallel copy with pthreads. The file list is pushed
 * into a blocking queue; N workers pop jobs and copy them. Each worker keeps
 * its own statistics (no locking on the hot path); they are merged at the end. */
#include "platform.h"
#include "pool.h"
#include "copy_core.h"
#include "jobqueue.h"
#include "logger.h"
#include "verify.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    job_queue_t          *queue;
    const mycp_options_t *opt;
    progress_t           *prog;
    copy_stats_t          stats;
} worker_t;

static void *worker_main(void *arg)
{
    worker_t *w = (worker_t *)arg;
    file_node_t *job;

    while ((job = (file_node_t *)jq_pop(w->queue)) != NULL) {
        int rc = copy_file(job->src, job->dst, w->opt, w->prog, &w->stats);

        if (rc == MYCP_OK && w->opt->verify) {
            if (verify_copy(job->src, job->dst, w->opt->buffer_size) == 0)
                w->stats.files_verified++;
            else
                w->stats.verify_failed++;
        }
    }
    return NULL;
}

int pool_run(const copy_plan_t *plan, const mycp_options_t *opt,
             progress_t *prog, copy_stats_t *total)
{
    job_queue_t q;
    worker_t *workers;
    pthread_t *tids;
    file_node_t *f;
    int nthreads = opt->jobs, created = 0, i;

    if (plan->file_count == 0)
        return 0;
    if (nthreads < 1)
        nthreads = 1;
    if ((unsigned long)nthreads > plan->file_count)
        nthreads = (int)plan->file_count;

    if (jq_init(&q) != 0) {
        LOG_ERROR("cannot initialise job queue");
        return -1;
    }
    for (f = plan->head; f != NULL; f = f->next) {
        if (jq_push(&q, f) != 0) {
            LOG_ERROR("out of memory while queueing jobs");
            jq_destroy(&q);
            return -1;
        }
    }
    jq_close(&q);                       /* all jobs queued: workers stop when drained */

    workers = (worker_t *)calloc((size_t)nthreads, sizeof *workers);
    tids = (pthread_t *)calloc((size_t)nthreads, sizeof *tids);
    if (workers == NULL || tids == NULL) {
        LOG_ERROR("out of memory");
        free(workers);
        free(tids);
        jq_destroy(&q);
        return -1;
    }
    for (i = 0; i < nthreads; i++) {
        workers[i].queue = &q;
        workers[i].opt = opt;
        workers[i].prog = prog;
    }
    LOG_DEBUG("starting %d worker thread(s) for %lu file(s)", nthreads, plan->file_count);

    for (i = 0; i < nthreads; i++) {
        if (pthread_create(&tids[i], NULL, worker_main, &workers[i]) != 0) {
            LOG_WARN("could not start worker thread %d", i);
            break;
        }
        created++;
    }
    if (created == 0)                   /* fall back to running inline */
        worker_main(&workers[0]);
    for (i = 0; i < created; i++)
        pthread_join(tids[i], NULL);

    for (i = 0; i < nthreads; i++)
        stats_merge(total, &workers[i].stats);

    free(workers);
    free(tids);
    jq_destroy(&q);
    return 0;
}
