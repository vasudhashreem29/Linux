/* benchmark.c - Extension: copy performance benchmark.
 * Copies the file with a range of buffer sizes (array of results), takes the
 * best of several runs for each and reports throughput + number of syscalls.
 * One untimed warm-up copy first, so every measured run sees a warm page
 * cache and the comparison is fair (this measures syscall overhead, not disk). */
#include "platform.h"
#include "benchmark.h"
#include "copy_core.h"
#include "logger.h"
#include "util.h"

#include <stdio.h>
#include <string.h>

#define RUNS 3

typedef struct {
    size_t             buf;
    double             secs;
    double             mbps;
    unsigned long long reads;
} bench_result_t;

int benchmark_run(const char *src, const char *dst_path,
                  const mycp_options_t *opt, size_t *best_out)
{
    static const size_t sizes[] = { 512, 1024, 4096, 16384, 65536, 262144, 1048576, 4194304 };
    enum { N = sizeof sizes / sizeof sizes[0] };
    bench_result_t res[N];
    mycp_stat_t st;
    mycp_options_t o = *opt;
    copy_stats_t scratch;
    char tmp[MYCP_PATH_MAX], hb[32], err[128];
    size_t best = 0;
    int i, r, best_i = 0, ok = 0;

    if (mycp_stat(src, &st) != 0 || !MYCP_ISREG(st.st_mode)) {
        LOG_ERROR("benchmark needs a regular file as source");
        return -1;
    }
    if (snprintf(tmp, sizeof tmp, "%s.mycp_bench.tmp", dst_path) >= (int)sizeof tmp) {
        LOG_ERROR("destination path too long for benchmark");
        return -1;
    }

    o.preserve = 0; o.resume = 0; o.no_clobber = 0; o.verify = 0; o.show_progress = 0;

    /* warm-up */
    memset(&scratch, 0, sizeof scratch);
    o.buffer_size = 65536;
    if (copy_file(src, tmp, &o, NULL, &scratch) != MYCP_OK) {
        remove(tmp);
        return -1;
    }

    for (i = 0; i < N; i++) {
        res[i].buf = sizes[i];
        res[i].secs = 1e30;
        res[i].reads = 0;
        o.buffer_size = sizes[i];
        for (r = 0; r < RUNS; r++) {
            double t0, t1;
            copy_stats_t s;

            memset(&s, 0, sizeof s);
            t0 = util_now();
            if (copy_file(src, tmp, &o, NULL, &s) != MYCP_OK) {
                remove(tmp);
                return -1;
            }
            t1 = util_now();
            if (t1 - t0 < res[i].secs) {
                res[i].secs = t1 - t0;
                res[i].reads = s.read_calls;
            }
        }
        if (res[i].secs < 1e-9)
            res[i].secs = 1e-9;
        res[i].mbps = ((double)st.st_size / 1048576.0) / res[i].secs;
        if (i == 0 || res[i].secs < res[best_i].secs)
            best_i = i;
    }
    ok = 1;
    best = res[best_i].buf;

    if (remove(tmp) != 0)
        LOG_WARN("could not remove temporary file '%s': %s", tmp, util_errstr(errno, err, sizeof err));

    if (!opt->quiet) {
        util_human_size((unsigned long long)st.st_size, hb, sizeof hb);
        printf("== Copy benchmark: %s (%s, best of %d runs, warm cache) ==\n", src, hb, RUNS);
        printf("  %-10s %-12s %-14s %s\n", "Buffer", "Time (s)", "Throughput", "read() calls");
        for (i = 0; i < N; i++) {
            char bh[32];
            util_human_size(res[i].buf, bh, sizeof bh);
            printf("  %-10s %-12.5f %-9.1f MB/s %-12llu%s\n", bh, res[i].secs, res[i].mbps,
                   res[i].reads, i == best_i ? "  <- fastest" : "");
        }
        if (st.st_size < 1048576)
            printf("  (file is small; results are noisy - use a file of 10 MB or more)\n");
        printf("\n");
    }
    *best_out = best;
    return ok ? 0 : -1;
}
