/* cli.c - command-line parsing (supports -abc style groups and --long=value). */
#include "platform.h"
#include "cli.h"
#include "util.h"

#include <stdlib.h>
#include <string.h>

typedef struct {
    const char *lname;
    char        sname;      /* 0 = long option only */
    int         has_arg;
    int         code;
} opt_def_t;

static const opt_def_t OPTS[] = {
    { "buffer-size", 's', 1, 's' },
    { "info",        'i', 0, 'i' },
    { "progress",    'p', 0, 'p' },
    { "no-preserve",  0,  0, 'N' },
    { "recursive",   'r', 0, 'r' },
    { "benchmark",   'b', 0, 'b' },
    { "verify",      'V', 0, 'V' },
    { "resume",      'c', 0, 'c' },
    { "no-clobber",  'n', 0, 'n' },
    { "jobs",        'j', 1, 'j' },
    { "log",         'l', 1, 'l' },
    { "verbose",     'v', 0, 'v' },
    { "quiet",       'q', 0, 'q' },
    { "help",        'h', 0, 'h' },
    { "version",      0,  0, 'W' }
};
#define NOPTS (sizeof OPTS / sizeof OPTS[0])

void cli_usage(FILE *f)
{
    fputs(
"mycp " MYCP_VERSION " - file copy utility built on low-level I/O (open/read/write)\n"
"\n"
"Usage: mycp [OPTIONS] SOURCE DEST\n"
"\n"
"Core options:\n"
"  -s, --buffer-size SIZE  I/O buffer size: 4096, 64K, 1M ...   (default 64K)\n"
"  -i, --info              show file information (size, permissions, times)\n"
"  -p, --progress          show a progress bar\n"
"      --no-preserve       do not preserve permissions/timestamps (default: preserve)\n"
"\n"
"Advanced options:\n"
"  -r, --recursive         copy directories recursively\n"
"  -j, --jobs N            copy N files in parallel (threads, 1-64; default 1)\n"
"  -V, --verify            verify every copy (byte compare + checksum)\n"
"  -c, --resume            continue an interrupted copy\n"
"  -b, --benchmark         benchmark buffer sizes first and use the fastest\n"
"  -l, --log FILE          append a log of all operations to FILE\n"
"  -n, --no-clobber        never overwrite existing files\n"
"  -v, --verbose           print every operation\n"
"  -q, --quiet             print errors only\n"
"  -h, --help              show this help        --version  show version\n"
"\n"
"Examples:\n"
"  mycp a.bin b.bin                    basic copy\n"
"  mycp -s 1M -i -p big.iso /backup/   1 MiB buffer, file info, progress bar\n"
"  mycp -r -j 4 -V -l bk.log data/ /backup/data   parallel, verified, logged\n"
"  mycp -c big.iso /backup/big.iso     resume after an interruption\n"
"\n"
"Exit status: 0 success, 1 copy/verify failure, 2 usage error, 130 interrupted.\n",
    f);
}

static int apply(int code, const char *val, cli_args_t *a)
{
    char *end;
    long j;

    switch (code) {
    case 's':
        if (util_parse_size(val, &a->opt.buffer_size) != 0) {
            fprintf(stderr, "mycp: invalid buffer size '%s' (use e.g. 4096, 64K, 1M; max 256M)\n", val);
            return -1;
        }
        a->opt.buffer_set = 1;
        break;
    case 'i': a->opt.show_info = 1; break;
    case 'p': a->opt.show_progress = 1; break;
    case 'N': a->opt.preserve = 0; break;
    case 'r': a->opt.recursive = 1; break;
    case 'b': a->opt.benchmark = 1; break;
    case 'V': a->opt.verify = 1; break;
    case 'c': a->opt.resume = 1; break;
    case 'n': a->opt.no_clobber = 1; break;
    case 'v': a->opt.verbose = 1; break;
    case 'q': a->opt.quiet = 1; break;
    case 'l': a->opt.log_path = val; break;
    case 'j':
        j = strtol(val, &end, 10);
        if (*val == '\0' || *end != '\0' || j < 1 || j > MYCP_MAX_JOBS) {
            fprintf(stderr, "mycp: invalid job count '%s' (1-%d)\n", val, MYCP_MAX_JOBS);
            return -1;
        }
        a->opt.jobs = (int)j;
        break;
    case 'h': cli_usage(stdout); return 1;
    case 'W': printf("mycp %s\n", MYCP_VERSION); return 1;
    default:  return -1;
    }
    return 0;
}

int cli_parse(int argc, char **argv, cli_args_t *out)
{
    const char *pos[2] = { NULL, NULL };
    int npos = 0, only_pos = 0, i;

    memset(out, 0, sizeof *out);
    out->opt.buffer_size = MYCP_DEFAULT_BUFFER;
    out->opt.preserve = 1;
    out->opt.jobs = 1;

    for (i = 1; i < argc; i++) {
        const char *a = argv[i];
        int r;

        if (!only_pos && strcmp(a, "--") == 0) {
            only_pos = 1;
        } else if (!only_pos && a[0] == '-' && a[1] == '-') {
            const char *name = a + 2, *eq = strchr(name, '=');
            size_t nlen = eq ? (size_t)(eq - name) : strlen(name);
            size_t k;
            const opt_def_t *d = NULL;

            for (k = 0; k < NOPTS; k++)
                if (strlen(OPTS[k].lname) == nlen && strncmp(OPTS[k].lname, name, nlen) == 0)
                    d = &OPTS[k];
            if (d == NULL) {
                fprintf(stderr, "mycp: unknown option '%s' (try --help)\n", a);
                return -1;
            }
            if (d->has_arg) {
                const char *val = eq ? eq + 1 : (i + 1 < argc ? argv[++i] : NULL);
                if (val == NULL) {
                    fprintf(stderr, "mycp: option '--%s' needs a value\n", d->lname);
                    return -1;
                }
                r = apply(d->code, val, out);
            } else {
                if (eq) {
                    fprintf(stderr, "mycp: option '--%s' takes no value\n", d->lname);
                    return -1;
                }
                r = apply(d->code, NULL, out);
            }
            if (r != 0)
                return r;
        } else if (!only_pos && a[0] == '-' && a[1] != '\0') {
            int j;
            for (j = 1; a[j] != '\0'; j++) {
                size_t k;
                const opt_def_t *d = NULL;

                for (k = 0; k < NOPTS; k++)
                    if (OPTS[k].sname && OPTS[k].sname == a[j])
                        d = &OPTS[k];
                if (d == NULL) {
                    fprintf(stderr, "mycp: unknown option '-%c' (try --help)\n", a[j]);
                    return -1;
                }
                if (d->has_arg) {
                    const char *val = a[j + 1] ? &a[j + 1] : (i + 1 < argc ? argv[++i] : NULL);
                    if (val == NULL) {
                        fprintf(stderr, "mycp: option '-%c' needs a value\n", a[j]);
                        return -1;
                    }
                    r = apply(d->code, val, out);
                    if (r != 0)
                        return r;
                    break;              /* rest of the group was the value */
                }
                r = apply(d->code, NULL, out);
                if (r != 0)
                    return r;
            }
        } else {
            if (npos == 2) {
                fprintf(stderr, "mycp: too many arguments (try --help)\n");
                return -1;
            }
            pos[npos++] = a;
        }
    }

    if (npos != 2) {
        fprintf(stderr, "mycp: expected SOURCE and DEST (try --help)\n");
        return -1;
    }
    out->src = pos[0];
    out->dst = pos[1];
    return 0;
}
