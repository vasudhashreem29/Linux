/* verify.c - Extension: copy verification. Compares source and destination in
 * lock-step (byte exact) and reports a 64-bit FNV-1a checksum of the data. */
#include "platform.h"
#include "verify.h"
#include "logger.h"
#include "util.h"

#include <stdlib.h>
#include <string.h>

#define FNV_OFFSET 14695981039346656037ULL
#define FNV_PRIME  1099511628211ULL

int verify_files(const char *src, const char *dst, size_t bufsize,
                 unsigned long long *hash_out, long long *diff_offset)
{
    int sfd, dfd, rc = 0;
    char *a, *b;
    long long pos = 0;
    unsigned long long h = FNV_OFFSET;

    sfd = mycp_open(src, MYCP_O_RDONLY | MYCP_O_BINARY);
    if (sfd < 0)
        return -1;
    dfd = mycp_open(dst, MYCP_O_RDONLY | MYCP_O_BINARY);
    if (dfd < 0) {
        mycp_close(sfd);
        return -1;
    }
    a = (char *)malloc(bufsize * 2);
    if (a == NULL) {
        mycp_close(sfd);
        mycp_close(dfd);
        return -1;
    }
    b = a + bufsize;

    for (;;) {
        long long ra = util_read_full(sfd, a, bufsize);
        long long rb = util_read_full(dfd, b, bufsize);
        size_t common, i;

        if (ra < 0 || rb < 0) { rc = -1; break; }
        common = (size_t)(ra < rb ? ra : rb);
        for (i = 0; i < (size_t)ra; i++) {
            h ^= (unsigned char)a[i];
            h *= FNV_PRIME;
        }
        if (memcmp(a, b, common) != 0) {
            for (i = 0; i < common && a[i] == b[i]; i++)
                ;
            pos += (long long)i;
            rc = 1;
            break;
        }
        pos += (long long)common;
        if (ra != rb) {                 /* different lengths */
            rc = 1;
            break;
        }
        if (ra == 0)
            break;                      /* both at EOF: identical */
    }

    if (hash_out != NULL)
        *hash_out = h;
    if (diff_offset != NULL)
        *diff_offset = pos;
    free(a);
    mycp_close(sfd);
    mycp_close(dfd);
    return rc;
}

int verify_copy(const char *src, const char *dst, size_t bufsize)
{
    unsigned long long hash = 0;
    long long off = 0;
    int r = verify_files(src, dst, bufsize, &hash, &off);

    if (r == 0) {
        LOG_INFO("verified OK: '%s' (FNV-1a64 %016llx)", dst, hash);
        return 0;
    }
    if (r == 1)
        LOG_ERROR("VERIFY FAILED: '%s' differs from '%s' at byte %lld", dst, src, off);
    else
        LOG_ERROR("VERIFY FAILED: I/O error while comparing '%s' and '%s'", src, dst);
    return -1;
}
