/* jobqueue.c - FIFO queue implemented as a singly linked list (data structure
 * requirement: Queues + Linked Lists), guarded by a mutex + condition variable. */
#include "platform.h"
#include "jobqueue.h"

#include <stdlib.h>

int jq_init(job_queue_t *q)
{
    q->head = q->tail = NULL;
    q->size = 0;
    q->closed = 0;
    if (pthread_mutex_init(&q->lock, NULL) != 0)
        return -1;
    if (pthread_cond_init(&q->not_empty, NULL) != 0) {
        pthread_mutex_destroy(&q->lock);
        return -1;
    }
    return 0;
}

int jq_push(job_queue_t *q, void *data)
{
    jq_node_t *n = (jq_node_t *)malloc(sizeof *n);

    if (n == NULL)
        return -1;
    n->data = data;
    n->next = NULL;
    pthread_mutex_lock(&q->lock);
    if (q->tail != NULL)
        q->tail->next = n;
    else
        q->head = n;
    q->tail = n;
    q->size++;
    pthread_cond_signal(&q->not_empty);
    pthread_mutex_unlock(&q->lock);
    return 0;
}

void *jq_pop(job_queue_t *q)
{
    void *data = NULL;
    jq_node_t *n;

    pthread_mutex_lock(&q->lock);
    while (q->head == NULL && !q->closed)
        pthread_cond_wait(&q->not_empty, &q->lock);
    if (q->head != NULL) {
        n = q->head;
        q->head = n->next;
        if (q->head == NULL)
            q->tail = NULL;
        q->size--;
        data = n->data;
        free(n);
    }
    pthread_mutex_unlock(&q->lock);
    return data;
}

void jq_close(job_queue_t *q)
{
    pthread_mutex_lock(&q->lock);
    q->closed = 1;
    pthread_cond_broadcast(&q->not_empty);
    pthread_mutex_unlock(&q->lock);
}

void jq_destroy(job_queue_t *q)
{
    while (q->head != NULL) {
        jq_node_t *n = q->head;
        q->head = n->next;
        free(n);
    }
    pthread_cond_destroy(&q->not_empty);
    pthread_mutex_destroy(&q->lock);
}
