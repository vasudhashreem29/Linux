/* dirwalk.c - Extension: recursive directory copy.
 * Walks the source tree with opendir()/readdir(), creates the destination
 * directories and collects every regular file in a linked list (the "plan")
 * that the thread pool then copies. Directory permissions/times are applied
 * last so read-only directories do not block the copy. */
#include "platform.h"
#include "dirwalk.h"
#include "logger.h"
#include "util.h"

#include <dirent.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    copy_plan_t          *plan;
    const mycp_options_t *opt;
    mycp_stat_t           dst_root_st;
} walk_ctx_t;

void plan_init(copy_plan_t *plan)
{
    memset(plan, 0, sizeof *plan);
}

static int add_file(copy_plan_t *plan, const char *src, const char *dst, unsigned long long size)
{
    file_node_t *n = (file_node_t *)calloc(1, sizeof *n);

    if (n == NULL)
        return -1;
    n->src = util_strdup(src);
    n->dst = util_strdup(dst);
    n->size = size;
    if (n->src == NULL || n->dst == NULL) {
        free(n->src);
        free(n->dst);
        free(n);
        return -1;
    }
    if (plan->tail != NULL)
        plan->tail->next = n;
    else
        plan->head = n;
    plan->tail = n;
    plan->file_count++;
    plan->total_bytes += size;
    return 0;
}

static int add_dir(copy_plan_t *plan, const char *path, const mycp_stat_t *st)
{
    dir_node_t *n = (dir_node_t *)calloc(1, sizeof *n);

    if (n == NULL)
        return -1;
    n->path = util_strdup(path);
    if (n->path == NULL) {
        free(n);
        return -1;
    }
    n->mode  = (unsigned int)(st->st_mode & 0777);
    n->uid   = st->st_uid;
    n->gid   = st->st_gid;
    n->atime = (time_t)st->st_atime;
    n->mtime = (time_t)st->st_mtime;
    n->next  = plan->dirs;              /* prepend: children end up before parents */
    plan->dirs = n;
    plan->dir_count++;
    return 0;
}

static int ensure_dir(const char *path, int preserve)
{
    mycp_stat_t st;
    char err[128];

    if (mycp_stat(path, &st) == 0) {
        if (MYCP_ISDIR(st.st_mode))
            return 0;
        LOG_ERROR("'%s' exists and is not a directory", path);
        return -1;
    }
    if (mycp_mkdir(path, preserve ? 0700 : 0777) != 0 && errno != EEXIST) {
        LOG_ERROR("cannot create directory '%s': %s", path, util_errstr(errno, err, sizeof err));
        return -1;
    }
    return 0;
}

static void copy_symlink(walk_ctx_t *c, const char *sp, const char *dp)
{
    char target[MYCP_PATH_MAX], err[128];
    ssize_t n;
    mycp_stat_t tmp;

    if (c->opt->no_clobber && lstat(dp, &tmp) == 0) {
        LOG_INFO("skipping symlink '%s': destination exists", dp);
        return;
    }
    n = readlink(sp, target, sizeof target - 1);
    if (n < 0) {
        LOG_ERROR("cannot read symlink '%s': %s", sp, util_errstr(errno, err, sizeof err));
        c->plan->errors++;
        return;
    }
    target[n] = '\0';
    if (symlink(target, dp) != 0) {
        if (errno == EEXIST && unlink(dp) == 0 && symlink(target, dp) == 0) {
            /* replaced an existing entry */
        } else {
            LOG_ERROR("cannot create symlink '%s': %s", dp, util_errstr(errno, err, sizeof err));
            c->plan->errors++;
            return;
        }
    }
    c->plan->symlink_count++;
    LOG_INFO("symlink '%s' -> '%s'", dp, target);
}

static void walk(walk_ctx_t *c, const char *src_dir, const char *dst_dir)
{
    DIR *d;
    struct dirent *e;
    char *sp, *dp, err[128];

    d = opendir(src_dir);
    if (d == NULL) {
        LOG_ERROR("cannot open directory '%s': %s", src_dir, util_errstr(errno, err, sizeof err));
        c->plan->errors++;
        return;
    }
    /* Heap buffers keep the stack small even for very deep trees. */
    sp = (char *)malloc(MYCP_PATH_MAX);
    dp = (char *)malloc(MYCP_PATH_MAX);
    if (sp == NULL || dp == NULL) {
        LOG_ERROR("out of memory");
        c->plan->errors++;
        free(sp);
        free(dp);
        closedir(d);
        return;
    }

    while ((e = readdir(d)) != NULL && !g_interrupted) {
        mycp_stat_t st;

        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0)
            continue;
        if (util_path_join(sp, MYCP_PATH_MAX, src_dir, e->d_name) != 0 ||
            util_path_join(dp, MYCP_PATH_MAX, dst_dir, e->d_name) != 0) {
            LOG_ERROR("path too long below '%s'", src_dir);
            c->plan->errors++;
            continue;
        }
        if (mycp_lstat(sp, &st) != 0) {
            LOG_ERROR("cannot stat '%s': %s", sp, util_errstr(errno, err, sizeof err));
            c->plan->errors++;
            continue;
        }

        if (MYCP_ISDIR(st.st_mode)) {
            if (mycp_same_file(&st, &c->dst_root_st)) {
                LOG_WARN("skipping '%s': it is the destination directory", sp);
                continue;
            }
            if (ensure_dir(dp, c->opt->preserve) != 0) {
                c->plan->errors++;
                continue;
            }
            if (add_dir(c->plan, dp, &st) != 0) {
                LOG_ERROR("out of memory");
                c->plan->errors++;
                continue;
            }
            walk(c, sp, dp);
        } else if (MYCP_ISREG(st.st_mode)) {
            if (add_file(c->plan, sp, dp, (unsigned long long)st.st_size) != 0) {
                LOG_ERROR("out of memory");
                c->plan->errors++;
            }
        } else if (MYCP_ISLNK(st.st_mode)) {
            copy_symlink(c, sp, dp);
        } else {
            LOG_WARN("skipping special file '%s'", sp);
            c->plan->skipped_special++;
        }
    }

    free(sp);
    free(dp);
    closedir(d);
}

int plan_build(copy_plan_t *plan, const char *src_root, const char *dst_root,
               const mycp_options_t *opt)
{
    walk_ctx_t ctx;
    mycp_stat_t sst;
    char err[128];

    if (mycp_stat(src_root, &sst) != 0) {
        LOG_ERROR("cannot stat '%s': %s", src_root, util_errstr(errno, err, sizeof err));
        return -1;
    }
    if (ensure_dir(dst_root, opt->preserve) != 0)
        return -1;
    if (mycp_stat(dst_root, &ctx.dst_root_st) != 0) {
        LOG_ERROR("cannot stat '%s': %s", dst_root, util_errstr(errno, err, sizeof err));
        return -1;
    }
    if (mycp_same_file(&sst, &ctx.dst_root_st)) {
        LOG_ERROR("'%s' and '%s' are the same directory", src_root, dst_root);
        return -1;
    }
    ctx.plan = plan;
    ctx.opt = opt;

    if (add_dir(plan, dst_root, &sst) != 0) {
        LOG_ERROR("out of memory");
        return -1;
    }
    walk(&ctx, src_root, dst_root);
    return 0;
}

void plan_apply_dir_attrs(const copy_plan_t *plan, const mycp_options_t *opt)
{
    const dir_node_t *d;
    char err[128];

    if (!opt->preserve)
        return;
    for (d = plan->dirs; d != NULL; d = d->next) {     /* children before parents */
        mycp_utimbuf_t ub;

        if (chown(d->path, d->uid, d->gid) != 0 && errno != EPERM)
            LOG_WARN("cannot preserve owner of directory '%s'", d->path);
        if (mycp_chmod(d->path, d->mode) != 0)
            LOG_WARN("cannot set permissions on directory '%s': %s", d->path,
                     util_errstr(errno, err, sizeof err));
        ub.actime = d->atime;
        ub.modtime = d->mtime;
        if (mycp_utime(d->path, &ub) != 0)
            LOG_DEBUG("cannot set times on directory '%s'", d->path);
    }
}

void plan_free(copy_plan_t *plan)
{
    file_node_t *f = plan->head;
    dir_node_t *d = plan->dirs;

    while (f != NULL) {
        file_node_t *next = f->next;
        free(f->src);
        free(f->dst);
        free(f);
        f = next;
    }
    while (d != NULL) {
        dir_node_t *next = d->next;
        free(d->path);
        free(d);
        d = next;
    }
    memset(plan, 0, sizeof *plan);
}
