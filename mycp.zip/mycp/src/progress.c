/* progress.c - Level 4: progress bar with percentage, size, speed. */
#include "platform.h"
#include "progress.h"
#include "util.h"

#include <stdio.h>
#include <string.h>

#define BAR_WIDTH 30

static progress_t *g_active = NULL;

void progress_init(progress_t *p, unsigned long long total, int enabled)
{
    memset(p, 0, sizeof *p);
    pthread_mutex_init(&p->lock, NULL);
    p->total   = total;
    p->enabled = enabled;
    p->tty     = mycp_isatty(mycp_fileno(stderr)) ? 1 : 0;
    p->start   = util_now();
    if (enabled)
        g_active = p;
}

/* Caller holds p->lock. */
static void draw(progress_t *p, double now)
{
    char bar[BAR_WIDTH + 1], line[160], hd[32], ht[32], hs[32];
    unsigned long long shown = p->done > p->total ? p->total : p->done;
    int pct = p->total ? (int)(shown * 100ULL / p->total) : 100;
    int filled = pct * BAR_WIDTH / 100, i;
    double elapsed = now - p->start;
    double speed = elapsed > 0.0 ? (double)p->done / elapsed : 0.0;

    for (i = 0; i < BAR_WIDTH; i++)
        bar[i] = (i < filled) ? '#' : '-';
    bar[BAR_WIDTH] = '\0';

    util_human_size(shown, hd, sizeof hd);
    util_human_size(p->total, ht, sizeof ht);
    util_human_size((unsigned long long)speed, hs, sizeof hs);
    snprintf(line, sizeof line, "[%s] %3d%%  %s / %s  %s/s", bar, pct, hd, ht, hs);
    fprintf(stderr, "\r%-79s", line);
    fflush(stderr);
    p->last_draw = now;
}

void progress_add(progress_t *p, unsigned long long n)
{
    if (p == NULL)
        return;
    pthread_mutex_lock(&p->lock);
    p->done += n;
    if (p->enabled && p->tty) {
        double now = util_now();
        if (now - p->last_draw >= 0.1)        /* redraw at most 10x / second */
            draw(p, now);
    }
    pthread_mutex_unlock(&p->lock);
}

void progress_finish(progress_t *p)
{
    pthread_mutex_lock(&p->lock);
    if (p->enabled && p->tty) {
        draw(p, util_now());
        fputc('\n', stderr);
        fflush(stderr);
    }
    if (g_active == p)
        g_active = NULL;
    pthread_mutex_unlock(&p->lock);
}

void progress_destroy(progress_t *p)
{
    pthread_mutex_destroy(&p->lock);
}

void progress_clear_active(void)
{
    progress_t *p = g_active;

    if (p != NULL && p->enabled && p->tty) {
        fprintf(stderr, "\r%79s\r", "");
        fflush(stderr);
    }
}
