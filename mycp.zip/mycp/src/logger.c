/* logger.c - thread-safe logging. The log file is written with open()/write()
 * in O_APPEND mode, so every line is one atomic append. */
#include "platform.h"
#include "logger.h"
#include "util.h"

#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static int              g_fd      = -1;
static int              g_verbose = 0;
static int              g_quiet   = 0;
static void           (*g_hook)(void) = NULL;
static pthread_mutex_t  g_lock    = PTHREAD_MUTEX_INITIALIZER;

static const char *LEVEL_NAME[] = { "DEBUG", "INFO ", "WARN ", "ERROR" };

int logger_init(const char *path, int verbose, int quiet)
{
    g_verbose = verbose;
    g_quiet   = quiet;
    if (path != NULL) {
        char err[128];
        g_fd = mycp_open(path, MYCP_O_WRONLY | MYCP_O_CREAT | MYCP_O_APPEND | MYCP_O_BINARY, 0644);
        if (g_fd < 0) {
            fprintf(stderr, "mycp: cannot open log file '%s': %s\n", path,
                    util_errstr(errno, err, sizeof err));
            return -1;
        }
    }
    return 0;
}

void logger_close(void)
{
    if (g_fd >= 0) {
        mycp_close(g_fd);
        g_fd = -1;
    }
}

void logger_set_console_hook(void (*hook)(void))
{
    g_hook = hook;
}

void logger_log(log_level_t lvl, const char *fmt, ...)
{
    char    msg[1024], ts[32], line[1200];
    va_list ap;
    int     len, to_console;

    if (lvl == LOGLVL_DEBUG && !g_verbose)
        return;

    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    util_format_time(time(NULL), ts, sizeof ts);

    pthread_mutex_lock(&g_lock);

    if (g_fd >= 0) {
        len = snprintf(line, sizeof line, "%s [%s] %s\n", ts, LEVEL_NAME[lvl], msg);
        if (len > 0) {
            if ((size_t)len >= sizeof line) {
                len = (int)sizeof line - 1;
                line[len - 1] = '\n';
            }
            if (mycp_write(g_fd, line, (size_t)len) < 0) {
                /* logging must never abort the copy: ignore a failed log write */
            }
        }
    }

    /* Console: errors always, warnings unless quiet, info/debug if verbose. */
    to_console = (lvl == LOGLVL_ERROR) ||
                 (lvl == LOGLVL_WARN && !g_quiet) ||
                 (lvl <= LOGLVL_INFO && g_verbose && !g_quiet);
    if (to_console) {
        if (g_hook != NULL)
            g_hook();                         /* clear progress bar line */
        if (lvl == LOGLVL_ERROR)
            fprintf(stderr, "mycp: error: %s\n", msg);
        else if (lvl == LOGLVL_WARN)
            fprintf(stderr, "mycp: warning: %s\n", msg);
        else
            fprintf(stderr, "mycp: %s\n", msg);
    }

    pthread_mutex_unlock(&g_lock);
}
