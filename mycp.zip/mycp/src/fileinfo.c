/* fileinfo.c - Level 3: display file information using stat(). */
#include "platform.h"
#include "fileinfo.h"
#include "common.h"
#include "logger.h"
#include "util.h"

int fileinfo_print(const char *path, const char *label, FILE *out)
{
    mycp_stat_t st;
    char err[128], perm[11], size_h[32], mt[32], at[32];
    const char *type;

    if (mycp_lstat(path, &st) != 0) {
        LOG_ERROR("cannot stat '%s': %s", path, util_errstr(errno, err, sizeof err));
        return -1;
    }
    type = MYCP_ISDIR(st.st_mode) ? "directory"
         : MYCP_ISREG(st.st_mode) ? "regular file"
         : MYCP_ISLNK(st.st_mode) ? "symbolic link" : "other";

    util_mode_string((unsigned int)st.st_mode, perm);
    util_human_size((unsigned long long)st.st_size, size_h, sizeof size_h);
    util_format_time((time_t)st.st_mtime, mt, sizeof mt);
    util_format_time((time_t)st.st_atime, at, sizeof at);

    fprintf(out, "== %s information ==\n", label);
    fprintf(out, "  Path        : %s\n", path);
    fprintf(out, "  Type        : %s\n", type);
    fprintf(out, "  Size        : %s (%llu bytes)\n", size_h, (unsigned long long)st.st_size);
    fprintf(out, "  Permissions : %s (%04o)\n", perm, (unsigned int)(st.st_mode & 07777));
    fprintf(out, "  Modified    : %s\n", mt);
    fprintf(out, "  Accessed    : %s\n", at);
    fprintf(out, "  Inode/Links : %llu / %lu\n", (unsigned long long)st.st_ino,
            (unsigned long)st.st_nlink);
    fprintf(out, "  Owner       : uid=%lu gid=%lu\n", (unsigned long)st.st_uid,
            (unsigned long)st.st_gid);
    return 0;
}
