/* main.c - mycp: orchestration. Parses options, then runs one of
 *   - single file copy  (Levels 1-5, verify, resume, benchmark)
 *   - recursive copy    (directory walk + thread pool)
 * and prints the performance statistics. */
#include "platform.h"
#include "benchmark.h"
#include "cli.h"
#include "common.h"
#include "copy_core.h"
#include "dirwalk.h"
#include "fileinfo.h"
#include "logger.h"
#include "pool.h"
#include "progress.h"
#include "util.h"
#include "verify.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

volatile sig_atomic_t g_interrupted = 0;

static void on_signal(int sig)
{
    (void)sig;
    g_interrupted = 1;
}

static void install_signals(void)
{
    struct sigaction sa;

    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_signal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;                    /* no SA_RESTART: read() returns EINTR */
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
}

/* cp semantics: if DEST is an existing directory, copy INTO it. */
static int resolve_dest(const char *src, const char *dst, char *out, size_t n)
{
    mycp_stat_t st;
    char base[MYCP_PATH_MAX];

    if (mycp_stat(dst, &st) == 0 && MYCP_ISDIR(st.st_mode)) {
        if (util_basename(src, base, sizeof base) != 0 || strcmp(base, "..") == 0) {
            LOG_ERROR("cannot derive a name from '%s'; give an explicit destination name", src);
            return -1;
        }
        if (util_path_join(out, n, dst, base) != 0) {
            LOG_ERROR("destination path too long");
            return -1;
        }
        return 0;
    }
    if (snprintf(out, n, "%s", dst) >= (int)n) {
        LOG_ERROR("destination path too long");
        return -1;
    }
    return 0;
}

static void print_summary(const mycp_options_t *opt, const copy_stats_t *s, double secs,
                          const copy_plan_t *plan)
{
    char hb[32];
    double mbps = secs > 0.0 ? ((double)s->bytes_copied / 1048576.0) / secs : 0.0;

    if (opt->quiet)
        return;
    util_human_size(s->bytes_copied, hb, sizeof hb);
    printf("\n--- mycp summary ---\n");
    printf("Files copied  : %lu   (skipped %lu, failed %lu)\n",
           s->files_copied, s->files_skipped, s->files_failed);
    if (plan != NULL)
        printf("Directories   : %lu   (symlinks %lu, special files skipped %lu, walk errors %lu)\n",
               plan->dir_count, plan->symlink_count, plan->skipped_special, plan->errors);
    printf("Data copied   : %s (%llu bytes)\n", hb, s->bytes_copied);
    printf("Elapsed       : %.3f s\n", secs);
    printf("Throughput    : %.2f MB/s\n", mbps);
    printf("Buffer size   : %lu bytes   read() calls: %llu   write() calls: %llu\n",
           (unsigned long)opt->buffer_size, s->read_calls, s->write_calls);
    if (opt->verify)
        printf("Verification  : %lu OK, %lu FAILED\n", s->files_verified, s->verify_failed);
}

static int copy_single(const mycp_options_t *opt, const char *src, const char *dst,
                       const mycp_stat_t *sst)
{
    copy_stats_t st;
    progress_t prog;
    double t0, t1;
    int rc;

    memset(&st, 0, sizeof st);
    if (opt->show_info)
        fileinfo_print(src, "Source", stdout);

    progress_init(&prog, (unsigned long long)sst->st_size, opt->show_progress && !opt->quiet);
    t0 = util_now();
    rc = copy_file(src, dst, opt, &prog, &st);
    t1 = util_now();
    progress_finish(&prog);
    progress_destroy(&prog);

    if (rc == MYCP_OK && opt->verify) {
        if (verify_copy(src, dst, opt->buffer_size) == 0)
            st.files_verified++;
        else
            st.verify_failed++;
    }
    if (opt->show_info && (rc == MYCP_OK || rc == MYCP_SKIPPED))
        fileinfo_print(dst, "Destination", stdout);

    print_summary(opt, &st, t1 - t0, NULL);
    if (rc == MYCP_INTERRUPTED)
        return 130;
    return (rc == MYCP_ERROR || st.verify_failed > 0) ? 1 : 0;
}

static int copy_tree(const mycp_options_t *opt, const char *src, const char *dst)
{
    copy_plan_t plan;
    copy_stats_t st;
    progress_t prog;
    double t0, t1;
    int failed;

    memset(&st, 0, sizeof st);
    plan_init(&plan);
    if (opt->show_info)
        fileinfo_print(src, "Source", stdout);

    t0 = util_now();
    if (plan_build(&plan, src, dst, opt) != 0) {
        plan_free(&plan);
        return 1;
    }
    LOG_INFO("found %lu file(s) in %lu director(ies), %llu bytes", plan.file_count,
             plan.dir_count, plan.total_bytes);

    progress_init(&prog, plan.total_bytes, opt->show_progress && !opt->quiet);
    pool_run(&plan, opt, &prog, &st);
    progress_finish(&prog);
    progress_destroy(&prog);

    plan_apply_dir_attrs(&plan, opt);
    t1 = util_now();

    print_summary(opt, &st, t1 - t0, &plan);
    failed = (st.files_failed > 0 || st.verify_failed > 0 || plan.errors > 0);
    plan_free(&plan);
    if (g_interrupted)
        return 130;
    return failed ? 1 : 0;
}

static int run(cli_args_t *args)
{
    mycp_options_t *opt = &args->opt;
    mycp_stat_t sst;
    char dst[MYCP_PATH_MAX], err[128];
    int is_dir;

    if (mycp_stat(args->src, &sst) != 0) {
        LOG_ERROR("cannot stat '%s': %s", args->src, util_errstr(errno, err, sizeof err));
        return 1;
    }
    is_dir = MYCP_ISDIR(sst.st_mode);
    if (is_dir && !opt->recursive) {
        LOG_ERROR("'%s' is a directory (use -r to copy directories)", args->src);
        return 1;
    }
    if (resolve_dest(args->src, args->dst, dst, sizeof dst) != 0)
        return 1;

    LOG_INFO("mycp %s: '%s' -> '%s' (buffer %lu, jobs %d)", MYCP_VERSION, args->src, dst,
             (unsigned long)opt->buffer_size, opt->jobs);

    if (opt->benchmark) {
        size_t best;

        if (is_dir) {
            LOG_ERROR("--benchmark works on a single file, not on a directory");
            return 1;
        }
        if (benchmark_run(args->src, dst, opt, &best) != 0)
            return 1;
        if (!opt->buffer_set) {
            opt->buffer_size = best;
            LOG_INFO("using benchmark winner: %lu byte buffer", (unsigned long)best);
        }
    }
    return is_dir ? copy_tree(opt, args->src, dst) : copy_single(opt, args->src, dst, &sst);
}

int main(int argc, char **argv)
{
    cli_args_t args;
    int pr, rc;

    pr = cli_parse(argc, argv, &args);
    if (pr > 0)
        return 0;
    if (pr < 0)
        return 2;

    if (logger_init(args.opt.log_path, args.opt.verbose, args.opt.quiet) != 0)
        return 2;
    logger_set_console_hook(progress_clear_active);
    install_signals();

    rc = run(&args);
    if (g_interrupted) {
        fprintf(stderr, "\nmycp: interrupted. Partial files were kept; re-run with --resume to continue.\n");
        rc = 130;
    }
    logger_close();
    return rc;
}
