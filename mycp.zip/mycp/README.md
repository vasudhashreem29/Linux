# mycp - File Copy Utility using Low-Level I/O
**Enterprise Data Backup & Recovery System - Linux PoC** (C, GCC, Makefile, Linux, team of 3, 1 week)

`mycp` copies files and directory trees using only the system-call layer
(`open`, `read`, `write`, `lseek`, `stat/fstat`, `chmod`, `close`, `opendir/readdir`) and
`pthreads` - never `fread/fwrite/fopen/system()`.

## Build & run
```
make            # build ./mycp            (gcc, -Wall -Wextra -Wpedantic, zero warnings)
make test       # 127 automated tests
make debug      # AddressSanitizer + UBSan build (all tests pass clean)
./mycp --help
```

## Usage
```
mycp [OPTIONS] SOURCE DEST
  -s, --buffer-size SIZE   4096 | 64K | 1M ...  (default 64K, max 256M)      Level 2
  -i, --info               file information of source and destination         Level 3
  -p, --progress           progress bar (%, size, speed)                       Level 4
      --no-preserve        skip permission/timestamp preservation (default ON) Level 5
  -r, --recursive          recursive directory copy                            Extension
  -b, --benchmark          benchmark buffer sizes, use the fastest             Extension
  -V, --verify             byte-compare + FNV-1a checksum after copy           Extension
  -c, --resume             continue an interrupted copy                        Extension
  -l, --log FILE           timestamped log (INFO/WARN/ERROR)                   Extension
  -j, --jobs N             parallel copy with N threads                        (pthreads)
  -n, --no-clobber   -v, --verbose   -q, --quiet   -h, --help   --version
```
```
mycp a.bin b.bin                                  # Level 1
mycp -s 1M -i -p big.iso /backup/                 # Levels 2,3,4,5
mycp -r -j 4 -V -l backup.log data/ /backup/data  # recursive + parallel + verify + log
mycp -c big.iso /backup/big.iso                   # resume after Ctrl-C / crash
mycp -b -p big.iso /backup/big.iso                # benchmark, then copy with best buffer
```
Exit codes: `0` ok, `1` copy/verify failure, `2` usage error, `130` interrupted.

## Requirement checklist
| Requirement (from the PoC sheet) | Where | Test group |
|---|---|---|
| Level 1 Basic file copy | `copy_core.c` | Level 1 |
| Level 2 Configurable buffer size | `cli.c` (`-s`), `copy_core.c` | Level 2 |
| Level 3 File information display | `fileinfo.c` (`stat`) | Level 3 |
| Level 4 Progress bar | `progress.c` | Level 4 |
| Level 5 Preserve permissions | `copy_core.c` (`chmod`, `chown`, `utime`), `dirwalk.c` | Level 5 |
| Recursive directory copy | `dirwalk.c` (`opendir/readdir`) | Recursive |
| Copy performance benchmark | `benchmark.c` | Benchmark |
| Copy verification | `verify.c` | Verification |
| Resume interrupted copy | `resume.c` + SIGINT handling in `main.c` | Resume |
| Logging system | `logger.c` | Logging |
| Language C / GCC / Makefile | whole project, `Makefile` | - |
| Data structures: arrays, queues, linked lists | array: I/O buffers + benchmark results; linked lists: `copy_plan_t` file/dir lists; queue: `jobqueue.c` | Parallel |
| Operating system: Linux | POSIX system calls; `platform.h` keeps the call aliases in one place | all |
| Data storage: file handling | everything is file I/O | - |
| Concepts: open/read/write/close/lseek/stat/chmod/opendir/pthreads/buffer mgmt/error handling | `open/read/write/close` + `lseek` (resume) + `stat/fstat` + `chmod` + `opendir` + `pthread_*` | all |
| Coding efficiency: modular, naming, indentation, comments | 13 modules, `module_verb()` names, 4-space indent, header comment per file | - |
| Problem statement: various sizes, preserve perms, error handling, performance stats | summary after every run (time, MB/s, read/write calls) | - |

## Module map
```
include/ + src/
  main.c       orchestration, signals, summary          cli.c        option parsing
  copy_core.c  Levels 1,2,5 + resume integration        fileinfo.c   Level 3
  progress.c   Level 4                                  dirwalk.c    recursive walk -> linked lists
  pool.c       worker threads                           jobqueue.c   blocking FIFO queue (linked list)
  verify.c     verification                             resume.c     find safe resume offset
  benchmark.c  buffer-size benchmark                    logger.c     thread-safe logging
  util.c       sizes, paths, read_full/write_all        platform.h   system headers + aliases
tests/run_tests.sh   127 tests
```

## Design notes (good points to explain in a review)
* **Short writes / EINTR**: `write()` may write less than asked, so `util_write_all()` loops; `read()` and `write()` retry on `EINTR`.
* **Safe permissions**: with preserve on, the destination is created `0600` and the real mode is applied only after the data is written, so a private file is never briefly world-readable. Setuid/setgid/sticky bits are intentionally not copied.
* **`close()` is checked** (delayed write errors on network file systems).
* **Resume** does not trust the destination size: it compares existing bytes with the source and continues from the first difference, so a torn tail after a crash is repaired. Complete files are skipped.
* **Interrupts**: SIGINT/SIGTERM set a flag; copy loops stop cleanly, partial files are kept, exit code 130.
* **Directory recursion** skips the destination if it lies inside the source (no infinite loop), recreates symlinks instead of following them, and applies directory permissions last (so read-only dirs don't block the copy).
* **Parallel copy**: files are queued, N workers pop jobs; statistics are per-thread and merged at the end (no lock on the hot path). The log uses `O_APPEND` single-`write()` lines, so lines never interleave.
* **Benchmark** does an untimed warm-up and uses best-of-3, so it measures system-call overhead (page cache is warm), not disk speed.
* Buffer is capped to the file size, so copying thousands of small files with a big `-s` does not waste memory.

## Known limits
* Linux only (tested on Ubuntu, GCC 13). Ownership is preserved when run as root; as a normal user it is skipped silently (the OS forbids it).
* Extended attributes and ACLs are not copied. Sparse files are copied as full data (holes are written as zeros).
* Very deep trees keep one directory handle open per level.

## Test coverage (127 tests, also clean under AddressSanitizer/UBSan)
Basic copy, empty/small/3 MB files, buffer sizes 1 B-4 MB and invalid values, file info, progress bar (incl. real terminal),
permissions/timestamps/ownership, recursive trees (symlinks, empty and read-only dirs, copy-into-itself), 1-16 threads,
1500 small files, 60-level deep tree, odd file names, verification, resume (clean prefix, torn tail, unrelated/oversized
destination, real SIGINT), logging, benchmark, no-clobber, error handling and exit codes, and a 2.3 GiB file (64-bit offsets).

## Suggested split for 3 people (1 week)
| Member | Modules | Day plan |
|---|---|---|
| **A - Core** | `copy_core.c`, `resume.c`, `util.c`, `platform.h`, `main.c` | D1-2 Level 1,2,5; D3 resume; D4 hardening + edge cases |
| **B - Tree & threads** | `dirwalk.c`, `jobqueue.c`, `pool.c`, `cli.c` | D1 CLI; D2-3 recursive copy; D4 thread pool + queue |
| **C - Quality & reporting** | `fileinfo.c`, `progress.c`, `logger.c`, `verify.c`, `benchmark.c`, `tests/`, docs | D1-2 Level 3,4 + logger; D3 verify + benchmark; D4-5 tests, README |
| **All** | D5 integration + `make debug` sanitizer run; D6 code review (naming/indent/comments); D7 demo + buffer | |

Plan items from the sheet: brief freshers -> teams of 4 (here 3) with a lead -> modules (table above) -> roadmap (day plan above) -> daily progress tracking (daily 10-minute stand-up, `make test` must stay green).
